package jsp.springsecurity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import jsp.springsecurity.entity.Users;
import jsp.springsecurity.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;

	public ResponseEntity<Users> saveUser(Users user) {
		return new ResponseEntity<Users>(userRepository.save(user), HttpStatus.CREATED);
	}

	public ResponseEntity<List<Users>> getAllUser() {
		return new ResponseEntity<List<Users>>(userRepository.findAll(), HttpStatus.FOUND);
	}

}
