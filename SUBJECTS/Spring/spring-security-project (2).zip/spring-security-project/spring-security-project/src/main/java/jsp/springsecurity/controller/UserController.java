package jsp.springsecurity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jsp.springsecurity.entity.Users;
import jsp.springsecurity.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping
	public ResponseEntity<Users> saveUser(@RequestBody Users user){
		return userService.saveUser(user);
	}
	
	@GetMapping
	public ResponseEntity<List<Users>> getAllUsers(){
		return userService.getAllUser();
	}
}
