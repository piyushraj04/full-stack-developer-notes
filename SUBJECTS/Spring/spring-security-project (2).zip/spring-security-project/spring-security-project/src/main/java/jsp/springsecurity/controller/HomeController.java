package jsp.springsecurity.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	@GetMapping("/home")
	public String homePage() {
		return "Welcome to home page....!";
	}
	
	@GetMapping("/browse")
	public String browser() {
		return "Browser opened. Search for anything......!";
	}
	
	
	
	
}
