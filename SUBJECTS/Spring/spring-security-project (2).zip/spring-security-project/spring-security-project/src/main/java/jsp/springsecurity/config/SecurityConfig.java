package jsp.springsecurity.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity //disable default security impl. and enables user defined config
public class SecurityConfig {

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) {
		http
			.csrf(csrf -> csrf.disable())//protects browser-based application
			//from malicious put/post/get request
			//CSRF - Cross site request forgery (REST APIs are by default state less
			//and secure hence we disable CSRF
			.authorizeHttpRequests(auth -> auth //it will define who can access 
			//the endpoint
					.requestMatchers("/user").hasRole("USER")//only USER can access
					//  /user endpoint
					.requestMatchers("/home").hasRole("ADMIN")//only ADMIN can access 
					// /home endpoint
			.anyRequest()//any request which comes should be 
			//authenticated and authorized
			.authenticated())//user credentials is verified
			.httpBasic(Customizer.withDefaults());//removes form login and 
		//enables basic authentication(popup window)
		return http.build();
	}
	
	@Bean
	public UserDetailsService userDetailsService() {
		//user is hardcoded using InMemoryUserDetailsManager
		UserDetails user1 = User.withUsername("smith")
		.password(passwordEncoder().encode("smith@123"))
		.roles("USER")
		.build();
		
		UserDetails user2 = User.withUsername("riya")
				.password(passwordEncoder().encode("riya@123"))
				.roles("ADMIN")
				.build();
		
		return new InMemoryUserDetailsManager(user1, user2);
	}
	
	//UserDetailsService -> responsible for fetching user data from a
	//source(DB, in-memory)
	//UserDetails -> contains user security info
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
		//PasswordEncoder interface helps in encrypting the password using an 
		//implementing class BCryptPasswordEncoder
	}
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Bean
	//Configures DaoAuthenticaionProvider as the AuthenticationProvider to
	//authenticate user identity from DB
	public DaoAuthenticationProvider daoAuthenticationProvider() {
		DaoAuthenticationProvider dao = 
				new DaoAuthenticationProvider(userDetailsService);//pass the obj 
		//of UserDetailsService to fetch user info from DB
		dao.setPasswordEncoder(NoOpPasswordEncoder.getInstance());
		//encrypt the password using NoOpPasswordEncoder
		//setpasswordEncoder(PasswordEncoder ref)
		return dao;
	}
}

