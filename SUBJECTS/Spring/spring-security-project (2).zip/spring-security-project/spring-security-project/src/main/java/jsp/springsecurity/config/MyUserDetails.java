package jsp.springsecurity.config;

import java.util.Arrays;
import java.util.Collection;

import org.jspecify.annotations.Nullable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jsp.springsecurity.entity.Users;

public class MyUserDetails implements UserDetails {
	
	private Users users;
	
	public MyUserDetails(Users users) {
		this.users=users;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		SimpleGrantedAuthority authority = new SimpleGrantedAuthority(users.getRole());
		return Arrays.asList(authority);
	}

	@Override
	public @Nullable String getPassword() {
		return users.getPassword();
	}

	@Override
	public String getUsername() {
		return users.getUsername();
	}

}
