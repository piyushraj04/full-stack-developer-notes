package jsp.springsecurity.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jsp.springsecurity.config.MyUserDetails;
import jsp.springsecurity.entity.Users;
import jsp.springsecurity.repository.UserRepository;

@Service
public class MyUserDetailsService implements UserDetailsService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	//this method fetches user info based on username and return UserDetails Obj
	//hence create an impl. class for UserDetails
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Users> opt = userRepository.findByUsername(username);
		
		if(opt.isPresent()) {
			return new MyUserDetails(opt.get());
		}
		throw new UsernameNotFoundException("Username does not exist in DB");
		
	}

}
